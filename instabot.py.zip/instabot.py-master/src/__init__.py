from .instabot import InstaBot
